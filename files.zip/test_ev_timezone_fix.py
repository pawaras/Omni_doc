"""
ALR EV Timestamp Fix — PyCharm Local Test
==========================================
Tests the Python-level fix (Approach A) for the EV/UEV timezone offset.

THE BUG:
  REDSHIFT_UNLOAD SQL is a UNION ALL:
    Part 1 (AMI): has AT TIME ZONE → Eastern time ✅
    Part 2 (EV ch1000): NO AT TIME ZONE → raw UTC ❌
    Part 3 (UEV ch2000, not_nm only): NO AT TIME ZONE → raw UTC ❌

  The DataFrame arrives with mixed timezones. Python processing doesn't
  know the difference — it treats everything as Eastern.

THE FIX (in loadresearch.py, before each mass_market block):
  df = df.withColumn('read_strt_time',
      F.when(F.col('channel').isin(1000, 2000),
          F.from_utc_timestamp(F.col('read_strt_time'), 'America/New_York'))
      .otherwise(F.col('read_strt_time')))

PREREQUISITES:
  pip install pyspark

HOW TO RUN IN PYCHARM:
  1. Open this file in PyCharm
  2. Right-click → Run 'test_ev_timezone_fix'
  3. Or from terminal: python test_ev_timezone_fix.py
  4. To test a specific study date context: python test_ev_timezone_fix.py --date 2025-02-01
"""

import sys
from pyspark.sql import SparkSession
from pyspark.sql import functions as F
from pyspark.sql.functions import to_date
from pyspark.sql.window import Window


# ─────────────────────────────────────────────────────────────────────────────
# SETUP
# ─────────────────────────────────────────────────────────────────────────────

def create_spark():
    """Match production Spark config from loadresearch.py line 297."""
    spark = SparkSession.builder \
        .appName("ALR_EV_TZ_Fix_Test") \
        .master("local[*]") \
        .config("spark.sql.session.timeZone", "America/New_York") \
        .config("spark.sql.legacy.timeParserPolicy", "LEGACY") \
        .getOrCreate()
    spark.sparkContext.setLogLevel("ERROR")
    return spark


# Column schema matching JSON config column_names
COLUMNS = ['premiseid', 'metertype', 'read_strt_time', 'kwh', 'meterid', 'channel', 'uom', 'spi']


def build_test_data():
    """
    Simulate what REDSHIFT_UNLOAD produces after the SQL runs.
    
    This mirrors the UNION ALL structure in fpl_daily.json:
      Part 1: AMI from utl.meter_duration_read_fact 
              → SQL has AT TIME ZONE → values are Eastern
      Part 2: EV from billing_fpl_fplnw_consolidated.ev_read_hist 
              → SQL has NO AT TIME ZONE → values are raw UTC
      Part 3: UEV (mass_market_not_nm only)
              → Same issue as Part 2
    
    The UNLOAD dumps all this into a pipe-delimited CSV on S3.
    Spark reads the CSV with inferSchema=true, session.timeZone=America/New_York.
    All timestamps look the same — Spark can't tell UTC from Eastern.
    """
    
    # ── Part 1: AMI data (CORRECT — AT TIME ZONE already applied in SQL) ──
    # These represent actual Eastern times
    ami_data = [
        ("100001", "AMI_TYPE", "2025-02-01 00:00:00", 1.50, "MTR001", 1,    "kwh", 15),
        ("100001", "AMI_TYPE", "2025-02-01 00:15:00", 1.30, "MTR001", 1,    "kwh", 15),
        ("100001", "AMI_TYPE", "2025-02-01 12:00:00", 2.10, "MTR001", 1,    "kwh", 15),
        ("100001", "AMI_TYPE", "2025-02-01 20:00:00", 1.80, "MTR001", 1,    "kwh", 15),
        ("100001", "AMI_TYPE", "2025-02-01 23:45:00", 0.90, "MTR001", 1,    "kwh", 15),
    ]
    
    # ── Part 2: EV data (BROKEN — raw UTC from UNLOAD) ──
    # The actual Eastern times should be: midnight, 00:15, noon, 8PM, 11:45PM
    # But UNLOAD exported them as UTC (EST = UTC-5):
    ev_data = [
        ("EV_SITE1", "evmeter", "2025-02-01 05:00:00", 2.10, "CB001", 1000, "kwh", 15),  # midnight EST → 05:00 UTC
        ("EV_SITE1", "evmeter", "2025-02-01 05:15:00", 2.30, "CB001", 1000, "kwh", 15),  # 00:15 EST → 05:15 UTC
        ("EV_SITE1", "evmeter", "2025-02-01 17:00:00", 3.50, "CB001", 1000, "kwh", 15),  # noon EST → 17:00 UTC
        ("EV_SITE1", "evmeter", "2025-02-02 01:00:00", 2.80, "CB001", 1000, "kwh", 15),  # 8PM EST Feb1 → 01:00 UTC Feb2
        ("EV_SITE1", "evmeter", "2025-02-02 04:45:00", 1.20, "CB001", 1000, "kwh", 15),  # 11:45PM EST Feb1 → 04:45 UTC Feb2
    ]
    
    # ── Part 3: UEV data (mass_market_not_nm only — same issue as EV) ──
    uev_data = [
        ("EV_SITE1", "uevmeter", "2025-02-01 05:00:00", 0.50, "uevmeterid", 2000, "kwh", 15),  # midnight EST
        ("EV_SITE1", "uevmeter", "2025-02-01 17:00:00", 0.80, "uevmeterid", 2000, "kwh", 15),  # noon EST
    ]
    
    return ami_data, ev_data, uev_data


# ─────────────────────────────────────────────────────────────────────────────
# TEST 1: Reproduce the Bug
# ─────────────────────────────────────────────────────────────────────────────

def test_bug(spark):
    """Current production behavior — no fix applied."""
    print("\n" + "=" * 90)
    print("TEST 1: BUG — Current Production (no fix)")
    print("=" * 90)
    
    ami, ev, uev = build_test_data()
    df = spark.createDataFrame(ami + ev + uev, COLUMNS)
    
    # ── This is what loadresearch.py does (lines 1248-1251) ──
    df = df.withColumn('read_date', to_date(F.col('read_strt_time'), 'yyyy-MM-dd'))
    df = df.withColumn('premiseid', F.col("premiseid").cast('string'))
    df = df.withColumn('read_strt_time', F.col("read_strt_time").cast('timestamp'))
    
    print("\n── AMI (ch1) — should be correct ──")
    df.filter(F.col('channel') == 1).select(
        'premiseid', 'channel', 'read_strt_time', 'read_date', 'kwh'
    ).orderBy('read_strt_time').show(truncate=False)
    
    print("── EV (ch1000) — BUG: timestamps are 5 hours ahead ──")
    df.filter(F.col('channel') == 1000).select(
        'premiseid', 'channel', 'read_strt_time', 'read_date', 'kwh'
    ).orderBy('read_strt_time').show(truncate=False)
    
    print("── UEV (ch2000) — BUG: same issue ──")
    df.filter(F.col('channel') == 2000).select(
        'premiseid', 'channel', 'read_strt_time', 'read_date', 'kwh'
    ).orderBy('read_strt_time').show(truncate=False)
    
    # Count date mismatches
    ev_wrong_date = df.filter(
        (F.col('channel').isin(1000, 2000)) & 
        (F.col('read_date') != F.lit('2025-02-01'))
    ).count()
    
    print(f"BUG IMPACT: {ev_wrong_date} EV/UEV rows have WRONG read_date (should all be 2025-02-01)")
    print("  → These rows would fail billing period joins (read_date >= billstart AND read_date < billstop)")
    print("  → Evening readings (8PM-midnight EST) land on next day → missing from billing aggregation")
    
    return df


# ─────────────────────────────────────────────────────────────────────────────
# TEST 2: Apply the Python Fix
# ─────────────────────────────────────────────────────────────────────────────

def test_fix(spark):
    """Apply the channel-conditional from_utc_timestamp fix."""
    print("\n" + "=" * 90)
    print("TEST 2: FIX — After applying Python fix in loadresearch.py")
    print("=" * 90)
    
    ami, ev, uev = build_test_data()
    df = spark.createDataFrame(ami + ev + uev, COLUMNS)
    
    # ═══════════════════════════════════════════════════════════════════════
    # THIS IS THE FIX — add this before the mass_market_nm/not_nm blocks
    # in loadresearch.py (before line 1118 and before line 1248)
    # ═══════════════════════════════════════════════════════════════════════
    df = df.withColumn('read_strt_time',
        F.when(F.col('channel').isin(1000, 2000),
            F.from_utc_timestamp(F.col('read_strt_time'), 'America/New_York'))
        .otherwise(F.col('read_strt_time')))
    # ═══════════════════════════════════════════════════════════════════════
    
    # ── Continue with normal processing (lines 1248-1251) ──
    df = df.withColumn('read_date', to_date(F.col('read_strt_time'), 'yyyy-MM-dd'))
    df = df.withColumn('premiseid', F.col("premiseid").cast('string'))
    df = df.withColumn('read_strt_time', F.col("read_strt_time").cast('timestamp'))
    
    print("\n── AMI (ch1) — unchanged, still correct ──")
    df.filter(F.col('channel') == 1).select(
        'premiseid', 'channel', 'read_strt_time', 'read_date', 'kwh'
    ).orderBy('read_strt_time').show(truncate=False)
    
    print("── EV (ch1000) — FIXED: correct Eastern times ──")
    df.filter(F.col('channel') == 1000).select(
        'premiseid', 'channel', 'read_strt_time', 'read_date', 'kwh'
    ).orderBy('read_strt_time').show(truncate=False)
    
    print("── UEV (ch2000) — FIXED: correct Eastern times ──")
    df.filter(F.col('channel') == 2000).select(
        'premiseid', 'channel', 'read_strt_time', 'read_date', 'kwh'
    ).orderBy('read_strt_time').show(truncate=False)
    
    # Verify all dates are correct
    all_feb1 = df.filter(F.col('read_date') == F.lit('2025-02-01')).count()
    total = df.count()
    
    print(f"VERIFICATION: {all_feb1}/{total} rows have read_date = 2025-02-01")
    assert all_feb1 == total, f"FAIL: Expected all {total} rows on 2025-02-01, got {all_feb1}"
    print("  ✅ ALL rows have correct read_date!")
    
    return df


# ─────────────────────────────────────────────────────────────────────────────
# TEST 3: Verify AMI data is NOT double-shifted
# ─────────────────────────────────────────────────────────────────────────────

def test_no_double_shift(spark):
    """Confirm the conditional fix doesn't touch AMI data."""
    print("\n" + "=" * 90)
    print("TEST 3: Verify AMI data is NOT affected by the fix")
    print("=" * 90)
    
    ami, ev, uev = build_test_data()
    
    # Create two DataFrames: before and after fix
    df_before = spark.createDataFrame(ami, COLUMNS)
    df_after = spark.createDataFrame(ami, COLUMNS)
    
    # Apply fix to df_after
    df_after = df_after.withColumn('read_strt_time',
        F.when(F.col('channel').isin(1000, 2000),
            F.from_utc_timestamp(F.col('read_strt_time'), 'America/New_York'))
        .otherwise(F.col('read_strt_time')))
    
    # Cast both
    df_before = df_before.withColumn('read_strt_time', F.col('read_strt_time').cast('timestamp'))
    df_after = df_after.withColumn('read_strt_time', F.col('read_strt_time').cast('timestamp'))
    
    # Compare
    before_ts = [row.read_strt_time for row in df_before.select('read_strt_time').collect()]
    after_ts = [row.read_strt_time for row in df_after.select('read_strt_time').collect()]
    
    match = all(b == a for b, a in zip(before_ts, after_ts))
    print(f"\n  AMI timestamps before fix: {before_ts}")
    print(f"  AMI timestamps after fix:  {after_ts}")
    print(f"  Match: {match}")
    assert match, "FAIL: AMI timestamps were modified by the fix!"
    print("  ✅ AMI data is identical — fix only touches ch1000/ch2000")


# ─────────────────────────────────────────────────────────────────────────────
# TEST 4: DST Transition
# ─────────────────────────────────────────────────────────────────────────────

def test_dst(spark):
    """Test fix behavior around DST transitions."""
    print("\n" + "=" * 90)
    print("TEST 4: DST Boundary — Spring Forward (March 9, 2025)")
    print("=" * 90)
    print("  Before 2AM: EST (UTC-5)")
    print("  After  3AM: EDT (UTC-4)")
    
    # EV readings as UTC around the DST transition
    dst_data = [
        # UTC 06:30 = 01:30 EST (before transition)
        ("EV1", "evmeter", "2025-03-09 06:30:00", 1.0, "CB1", 1000, "kwh", 15),
        # UTC 06:45 = 01:45 EST (before transition)
        ("EV1", "evmeter", "2025-03-09 06:45:00", 1.1, "CB1", 1000, "kwh", 15),
        # UTC 07:00 = 03:00 EDT (clocks jump forward — 02:00-02:59 doesn't exist)
        ("EV1", "evmeter", "2025-03-09 07:00:00", 1.2, "CB1", 1000, "kwh", 15),
        # UTC 07:15 = 03:15 EDT
        ("EV1", "evmeter", "2025-03-09 07:15:00", 1.3, "CB1", 1000, "kwh", 15),
        # UTC 08:00 = 04:00 EDT
        ("EV1", "evmeter", "2025-03-09 08:00:00", 1.5, "CB1", 1000, "kwh", 15),
    ]
    
    df = spark.createDataFrame(dst_data, COLUMNS)
    
    # Apply fix
    df = df.withColumn('read_strt_time',
        F.when(F.col('channel').isin(1000, 2000),
            F.from_utc_timestamp(F.col('read_strt_time'), 'America/New_York'))
        .otherwise(F.col('read_strt_time')))
    
    df = df.withColumn('read_strt_time', F.col('read_strt_time').cast('timestamp'))
    df = df.withColumn('read_date', to_date(F.col('read_strt_time'), 'yyyy-MM-dd'))
    
    print("\nFixed EV timestamps around DST spring-forward:")
    df.select('read_strt_time', 'read_date', 'kwh').orderBy('read_strt_time').show(truncate=False)
    
    print("  CHECK: 06:30 UTC → 01:30 EST (before transition)")
    print("  CHECK: 07:00 UTC → 03:00 EDT (after transition, 02:xx doesn't exist)")
    print("  CHECK: All readings on 2025-03-09")
    
    # Fall back
    print("\n" + "─" * 60)
    print("DST Boundary — Fall Back (November 2, 2025)")
    print("─" * 60)
    print("  Before 2AM EDT: EDT (UTC-4)")
    print("  After  1AM EST: EST (UTC-5)  ← clocks go back, 1AM happens twice")
    
    fall_data = [
        # UTC 05:00 = 01:00 EDT (first time)
        ("EV1", "evmeter", "2025-11-02 05:00:00", 2.0, "CB1", 1000, "kwh", 15),
        # UTC 05:45 = 01:45 EDT (still first occurrence)
        ("EV1", "evmeter", "2025-11-02 05:45:00", 2.1, "CB1", 1000, "kwh", 15),
        # UTC 06:00 = 01:00 EST (second time — clocks fell back)
        ("EV1", "evmeter", "2025-11-02 06:00:00", 2.2, "CB1", 1000, "kwh", 15),
        # UTC 06:15 = 01:15 EST
        ("EV1", "evmeter", "2025-11-02 06:15:00", 2.3, "CB1", 1000, "kwh", 15),
        # UTC 07:00 = 02:00 EST (unambiguous)
        ("EV1", "evmeter", "2025-11-02 07:00:00", 2.5, "CB1", 1000, "kwh", 15),
    ]
    
    df2 = spark.createDataFrame(fall_data, COLUMNS)
    df2 = df2.withColumn('read_strt_time',
        F.when(F.col('channel').isin(1000, 2000),
            F.from_utc_timestamp(F.col('read_strt_time'), 'America/New_York'))
        .otherwise(F.col('read_strt_time')))
    df2 = df2.withColumn('read_strt_time', F.col('read_strt_time').cast('timestamp'))
    df2 = df2.withColumn('read_date', to_date(F.col('read_strt_time'), 'yyyy-MM-dd'))
    
    print("\nFixed EV timestamps around DST fall-back:")
    df2.select('read_strt_time', 'read_date', 'kwh').orderBy('kwh').show(truncate=False)
    
    print("  NOTE: 01:00 appears twice (EDT then EST) — from_utc_timestamp handles")
    print("  this correctly because each UTC input maps to exactly one local time.")
    print("  The 4h→5h offset change is automatic.")


# ─────────────────────────────────────────────────────────────────────────────
# TEST 5: Full mass_market_not_nm Simulation
# ─────────────────────────────────────────────────────────────────────────────

def test_full_processing_chain(spark):
    """
    Simulate the complete mass_market_not_nm processing chain
    to verify the fix integrates correctly with downstream operations.
    
    This mirrors lines 1244-1360 in loadresearch.py.
    """
    print("\n" + "=" * 90)
    print("TEST 5: Full mass_market_not_nm Processing Chain")
    print("=" * 90)
    
    ami, ev, uev = build_test_data()
    df = spark.createDataFrame(ami + ev + uev, COLUMNS)
    
    # ═══════════════════════════════════════════════════════════════════════
    # THE FIX
    # ═══════════════════════════════════════════════════════════════════════
    df = df.withColumn('read_strt_time',
        F.when(F.col('channel').isin(1000, 2000),
            F.from_utc_timestamp(F.col('read_strt_time'), 'America/New_York'))
        .otherwise(F.col('read_strt_time')))
    
    # ── Line 1248-1252: Standard processing ──
    df_not_nm = df.withColumn('read_date', to_date(F.col('read_strt_time'), 'yyyy-MM-dd'))
    df_not_nm = df_not_nm.withColumn('premiseid', F.col("premiseid").cast('string'))
    df_not_nm = df_not_nm.withColumn('read_strt_time', F.col("read_strt_time").cast('timestamp'))
    df_not_nm = df_not_nm.dropDuplicates()
    
    df_not_nm.cache()
    df_not_nm.createOrReplaceTempView('mass_market_not_nm')
    
    # ── Verify the temp view has correct data ──
    print("\nTemp view 'mass_market_not_nm' — all channels combined:")
    spark.sql("""
        SELECT premiseid, channel, metertype, read_date, read_strt_time, kwh
        FROM mass_market_not_nm
        ORDER BY channel, read_strt_time
    """).show(20, truncate=False)
    
    # ── Simulate billing join (simplified) ──
    print("Simulated billing join (billstart=2025-02-01, billstop=2025-02-02):")
    spark.sql("""
        SELECT channel, metertype, 
               COUNT(*) as readings, 
               MIN(read_strt_time) as first_reading,
               MAX(read_strt_time) as last_reading,
               ROUND(SUM(kwh), 2) as total_kwh
        FROM mass_market_not_nm
        WHERE read_date >= '2025-02-01' AND read_date < '2025-02-02'
        GROUP BY channel, metertype
        ORDER BY channel
    """).show(truncate=False)
    
    # Verify all data falls within the expected date
    outside_date = spark.sql("""
        SELECT COUNT(*) as cnt FROM mass_market_not_nm 
        WHERE read_date != '2025-02-01'
    """).collect()[0].cnt
    
    assert outside_date == 0, f"FAIL: {outside_date} rows have wrong read_date!"
    print(f"  ✅ All {df_not_nm.count()} rows have read_date = 2025-02-01")
    print("  ✅ Billing join captures all readings for the day")
    
    spark.catalog.dropTempView('mass_market_not_nm')


# ─────────────────────────────────────────────────────────────────────────────
# TEST 6: Redshift Verification Queries (print only — run manually)
# ─────────────────────────────────────────────────────────────────────────────

def print_redshift_queries():
    """Print queries to run in Redshift/DBeaver to validate the data."""
    print("\n" + "=" * 90)
    print("REDSHIFT VERIFICATION QUERIES (run in DBeaver/Redshift)")
    print("=" * 90)
    
    print("""
-- STEP 1: Confirm column type
SELECT column_name, data_type
FROM information_schema.columns
WHERE table_schema = 'billing_fpl_fplnw_consolidated'
  AND table_name = 'ev_read_hist'
  AND column_name = 'read_strt_dttm';
-- Expected: 'timestamp with time zone'

-- STEP 2: Compare UTC vs Eastern for a specific date
SELECT 
    S.site_id,
    RH.read_strt_dttm AS utc_value,
    RH.read_strt_dttm AT TIME ZONE 'America/New_York' AS eastern_value,
    EXTRACT(HOUR FROM RH.read_strt_dttm) AS utc_hour,
    EXTRACT(HOUR FROM RH.read_strt_dttm AT TIME ZONE 'America/New_York') AS eastern_hour
FROM billing_fpl_fplnw_consolidated.ev_read_hist RH
JOIN billing_fpl_fplnw_consolidated.ev_site S 
    ON RH.site_pk = S.site_pk AND RH.prod_id = S.prod_id
WHERE rh.read_strt_dttm >= '2025-02-01'::timestamp with time zone
  AND rh.read_strt_dttm < '2025-02-02'::timestamp with time zone
ORDER BY RH.read_strt_dttm
LIMIT 20;

-- STEP 3: Count readings that cross midnight due to offset
-- (These are the ones that get wrong read_date in production)
SELECT 
    COUNT(*) as total_readings,
    SUM(CASE WHEN EXTRACT(HOUR FROM read_strt_dttm) >= 20 
              AND EXTRACT(HOUR FROM read_strt_dttm AT TIME ZONE 'America/New_York') < 20 
         THEN 1 ELSE 0 END) as cross_midnight_readings
FROM billing_fpl_fplnw_consolidated.ev_read_hist
WHERE read_strt_dttm >= '2025-02-01'::timestamp with time zone
  AND read_strt_dttm < '2025-02-02'::timestamp with time zone;
""")


# ─────────────────────────────────────────────────────────────────────────────
# MAIN
# ─────────────────────────────────────────────────────────────────────────────

if __name__ == "__main__":
    spark = create_spark()
    
    print("=" * 90)
    print("ALR EV TIMESTAMP FIX — PYCHARM LOCAL VALIDATION")
    print("=" * 90)
    print(f"Spark session.timeZone: {spark.conf.get('spark.sql.session.timeZone')}")
    print(f"timeParserPolicy: {spark.conf.get('spark.sql.legacy.timeParserPolicy')}")
    
    try:
        test_bug(spark)
        test_fix(spark)
        test_no_double_shift(spark)
        test_dst(spark)
        test_full_processing_chain(spark)
        print_redshift_queries()
        
        print("\n" + "=" * 90)
        print("ALL TESTS PASSED ✅")
        print("=" * 90)
        print()
        print("DEPLOYMENT STEPS:")
        print("  1. Run the Redshift queries above to confirm read_strt_dttm is TIMESTAMPTZ")
        print("  2. Add the fix to loadresearch.py:")
        print()
        print("     Before line 1118 (mass_market_nm block):")
        print("     Before line 1248 (mass_market_not_nm block):")
        print()
        print("       # Fix EV/UEV UTC timestamps from REDSHIFT_UNLOAD")
        print("       df = df.withColumn('read_strt_time',")
        print("           F.when(F.col('channel').isin(1000, 2000),")
        print("               F.from_utc_timestamp(F.col('read_strt_time'), 'America/New_York'))")
        print("           .otherwise(F.col('read_strt_time')))")
        print()
        print("  3. Deploy and run backdate for one affected date")
        print("  4. Compare output with Redshift eastern_value column")
        print("  5. If correct, backdate the full affected window (~Sept 27 → present)")
        
    except AssertionError as e:
        print(f"\n❌ TEST FAILED: {e}")
    except Exception as e:
        print(f"\n❌ ERROR: {e}")
        import traceback
        traceback.print_exc()
    finally:
        spark.stop()
