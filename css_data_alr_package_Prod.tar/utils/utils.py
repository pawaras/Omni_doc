from pyspark.sql.types import *



def to_fStrings(non_f_str):
    return eval(f'f"""{non_f_str}"""')


def empty(df):
    return df.rdd.isEmpty()


def drop_columns(df, columns_to_drop):
    df = df.drop(*columns_to_drop)
    # for col in columns_to_drop:
    # df = df.drop(col)
    return df


def rename_columns(df, to_rename=None):
    """Rename columns, for each key in rename_map, rename column from key to value

    rename_columns(df, to_rename=[
            ('test1', 'TEST1'),
            ('test2', 'CREATE_TIME'),
            ('test3', 'LAST_ACCESS_')])"""
    for old, new in to_rename:
        df = df.withColumnRenamed(old, new)
    return df


def get_schema_type(df, column_name):
    return df.select(column_name).schema.fields[0].dataType


def create_struct_schema(schema_list):
    struct_fields = []
    types_dict = {
        'int': IntegerType(),
        'long': LongType(),
        'string': StringType(),
        'boolean': BooleanType(),
        'timestamp': TimestampType(),
        'date': DateType(),
        'float': FloatType(),
        'double': DoubleType()
    }
    for item in schema_list:
        field_type = types_dict[item['col_type']]
        struct_fields.append(StructField(name=item['col_name'], dataType=field_type, nullable=item['nullable']))
    return StructType(struct_fields)


