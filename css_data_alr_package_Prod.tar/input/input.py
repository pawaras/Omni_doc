from pyspark.sql.types import *
import json
from datetime import datetime
from utils.utils import *
import awswrangler as wr
import pandas as pd


class Readers:

    def read_csv(self, path, delimiter=",", header=True, _schema=None):
        """Read CSV (comma-separated) file into DataFrame."""
        if _schema == None:
            return self.spark.read.format('csv').options(delimiter=delimiter, header=header).load(path)
        else:
            return self.spark.read.format('csv').options(delimiter=delimiter, header=header).schema(_schema).load(path)

    def read_cobol(self, path, _copybook):
        return self.spark.read.format("za.co.absa.cobrix.spark.cobol.source") \
            .option("copybook", _copybook) \
            .option("schema_retention_policy", "collapse_root") \
            .option("is_record_sequence", "true") \
            .option("floating_point_format", "IBM") \
            .load(path)



    def read_avro(self, path):
        """Convert a Avro  to dataframe."""
        return self.spark.read.format("avro").load(path)

    def read_json(self, path, _schema=None):
        """Convert a JSON  to dataframe."""
        return self.spark.read.json(path, multiLine=True, schema=_schema)

    def read_parquet(self, path):  # parquet
        """Load a parquet object from the file path, returning a DataFrame."""
        return self.spark.read.parquet(path)

    def read_hudi(self,connection, file_config):
        """Load from Apache Hudi, returning a DataFrame."""
        path = 's3://{}/{}{}'.format(connection['data_bucket_name'], file_config['file_config']['table_name'], file_config['file_config']['path'])
        return self.spark.read.format("org.apache.hudi").load(path)


    def read_athena(self, boto3_session, connection, sql ):
        s3_output_location = 's3://{}'.format(connection['s3_output'])
        pandas_df = wr.athena.read_sql_query(sql, database = connection['database_name'],
                                             ctas_approach=True,
                                             s3_output=s3_output_location,
                                             boto3_session=boto3_session)

        return self.spark.createDataFrame(pandas_df)

    def read_excel(self):
        return True

    def read_xml(self):
        return True

    def read_sql_table(self, table_name, driver, url_connection):
        """ Read SQL database table into a DataFrame. read_sql_table('table_name', 'jdbc:postgresql:db_name') """

        return self.spark.read \
            .format("jdbc") \
            .option("driver", driver) \
            .option("url", url_connection) \
            .option("dbtable", table_name) \
            .option("fetchsize", 10000)\
            .option("treatEmptyValuesAsNulls", "true") \
            .load()

    def read_sql_big_query(self, query, driver, url_connection):
        """Read SQL query into a DataFrame. read_sql_query('SELECT * FROM table_name', 'jdbc:postgresql:db_name')  """
        df = self.spark.read \
            .format("jdbc") \
            .option("driver", driver) \
            .option("url", url_connection) \
            .option("query", query) \
            .option("fetchsize", 900000) \
            .option("treatEmptyValuesAsNulls", "true") \
            .load()
        return df

    def read_sql_query(self, query, driver, url_connection):
        """Read SQL query into a DataFrame. read_sql_query('SELECT * FROM table_name', 'jdbc:postgresql:db_name')  """
        return self.spark.read \
            .format("jdbc") \
            .option("driver", driver) \
            .option("url", url_connection) \
            .option("query", query) \
            .option("fetchsize", 800000) \
            .option("treatEmptyValuesAsNulls", "true") \
            .load()

    def read_sqlserver_table(self, table_name, connection):
        return self.spark.read.format("jdbc") \
            .option("driver", connection['driver']) \
            .option("url", connection['url']) \
            .option("dbtable", table_name) \
            .option("user", connection['username']) \
            .option("password", connection['password']) \
            .option("treatEmptyValuesAsNulls", "true") \
            .load()

    def read_sql_query_jdbc(self, query, connection):
        return self.spark.read \
            .format("jdbc") \
            .option("driver", connection['driver']) \
            .option("url", connection['url']) \
            .option("query", query) \
            .option("user", connection['username'] ) \
            .option("password", connection['password']) \
            .option("fetchsize", 800000) \
            .option("treatEmptyValuesAsNulls", "true") \
            .load()

    def read_from_jdbc(self, connection, sql, options):
        """ Read SQL query or database table into a DataFrame. This function is a  wrapper around read_sql_table and read_sql_query"""
        file_config = options['file_config']
        url_connection = connection['url'] + "?user={}&password={}".format(connection['username'], connection['password']) if connection != None else '' # pragma: allowlist secret
        if file_config['sql_type'].upper() == 'DBTABLE':
            return self.read_sql_table(sql, connection['driver'], url_connection)

        if file_config['sql_type'].upper() == 'SQLSERVER':
            return self.read_sqlserver_table(sql, connection)

        if file_config['sql_type'].upper() == 'JDBC':
            return self.read_sql_query_jdbc(sql, connection)

        if file_config['sql_type'].upper() == 'SPARKSQL':
            return self.spark.sql(sql)

        if file_config['sql_type'].upper() == 'BIG':
            return self.read_sql_big_query(sql, connection['driver'], url_connection)
        else:
            return self.read_sql_query(sql, connection['driver'], url_connection)

    def read_from_file(self, _path, options):
        """ This function is a  wrapper around all others funtions from files"""
        df = self.spark.createDataFrame(self.spark.sparkContext.emptyRDD(), StructType([]))
        file_config = options['file_config']

        _schema = None
        if file_config['schema'] != "null":
            json_obj = file_config['schema']
            _schema = create_struct_schema(json_obj)
            print(_schema)

        file_format = file_config['format']

        if file_format.upper() == 'CSV':
            delimiter = file_config['delimiter']
            header = file_config['header']
            df = self.read_csv(_path, delimiter, header, _schema)
        elif file_format.upper() == 'JSON':
            df = self.read_json(_path, _schema)
        elif file_format.upper() == 'PARQUET':
            df = self.read_parquet(_path)
        elif file_format.upper() == 'COBOL':
            _copybook = file_config['copybook']
            df = self.read_cobol(_path, _copybook)


        return df

    def __init__(self, _spark):
        self.spark = _spark
