import re
from pyspark.sql.functions import *
from pyspark.sql.types import *
from utils.utils import *




sql_type_mappings = {'IntegerType': "INTEGER",
                     'LongType': "BIGINT",
                     'DoubleType': "DOUBLE PRECISION",
                     'FloatType': "REAL",
                     'ShortType': "INTEGER",
                     'ByteType': "SMALLINT",  # Redshift does not support the BYTE type.? don't remember check
                     'BooleanType': "BOOLEAN",
                     'TimestampType': "TIMESTAMP",
                     'DateType': "DATE",
                     'StringType': "VARCHAR",
                     'DecimalType': "DECIMAL"
                     }

# review data_type...need to include map
athena_type_mappings = {'IntegerType': "int",
                        'LongType': "bigint",
                        'DoubleType': "double",
                        'FloatType': "float",
                        'ShortType': "int",
                        'ByteType': "int",
                        'BooleanType': "boolean",
                        'TimestampType': "timestamp",
                        'DateType': "date",
                        'StringType': "string",
                        'DecimalType': "decimal",
                        'MapTypeStringTypeStringTypetrue': "map<string,string>"
                        }


def ddl_schemaString(schema: StructType, type_mappings, default_type, is_nullable=True, partition_col=None, from_writer=None):
    # Spark SQL Schema. to SQL schema
    s = []
    # default_type='TEXT'
    sep = "";
    for field in schema.fields:
        if field.name != partition_col:
            data_type = re.sub('[^a-zA-Z]+', '', '{}'.format(field.dataType))

            sql_type = type_mappings.get(data_type, default_type)

            if (data_type == 'StringType') & ("maxlength" in field.metadata) & (from_writer != 'Athena'):
                sql_type = '{}({})'.format(sql_type, field.metadata.get("maxlength"))
            elif (data_type == 'StringType'):
                sql_type = sql_type
            elif (data_type == 'DecimalType'):
                sql_type = '{}({},{})'.format(sql_type, field.dataType.precision, field.dataType.scale)

            nullable = "" if ((field.nullable) | (is_nullable == False)) else "NOT NULL"
            encoding = "ENCODE {}".format(field.metadata.get("encoding")) if "encoding" in field.metadata else ""
            # distkey
            s.append(
                '{} {} {} {} {}\n'.format(sep, field.name.replace("\"", "\\\"").lower(), sql_type, nullable, encoding))
            sep = ','
    return ''.join(s)

def get_actions( connection, partitionlist, partition_keys, table_name):

        data_bucket_name = connection['data_bucket_name']
        partition_drop = []
        partition_add = []
        PartitionKeysList = partition_keys.split(",")
        for row in partitionlist:

            location = ""
            partition = ""
            for item in PartitionKeysList:
                separator = ', ' if partition else ''
                location = location + "{}={}/".format(item, row[item])
                partition = partition + separator + "{}='{}'".format(item, row[item])

            partition_drop.append("PARTITION ({})".format(partition))
            partition_add.append(
                "PARTITION ({}) LOCATION 's3://{}/{}/{}'".format(partition, data_bucket_name, table_name, location))

        drop = "ALTER TABLE {} DROP IF EXISTS {} ;".format(table_name, ', '.join(partition_drop))
        add = "ALTER TABLE {} ADD IF NOT EXISTS {} ;".format(table_name, ' '.join(partition_add))
        return drop, add


def write_pandas_to_csv(_df, table_name, path):
    try:
        pandas_df = _df.toPandas()
        file_name = "{}\{}.csv".format(path, table_name)
        pandas_df.to_csv(file_name, index=False)
    except Exception as e:
        print(e)


# def write_csv(_df, table_name, path):


def write_to_parquet(_df, table_name, data_bucket_name, mode="overwrite", partition_cols=None):
    detail_target = "s3a://{}/{}".format(data_bucket_name, table_name)
    _df.write.mode(mode).format("parquet").partitionBy(partition_cols).save(detail_target)



@udf(ArrayType(LongType()))
def date_range(t1, t2, step=60*60):
    """Return a list of equally spaced points between t1 and t2 with stepsize step."""
    print([t1 + step*x for x in range(int(((t2 - t1))/step)+1)])
    return [t1 + step*x for x in range(int(((t2 - t1))/step)+1)]


def previous_day(date, dayOfWeek):
    return date_sub(next_day(date, dayOfWeek), 7)
