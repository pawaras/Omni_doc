from connection.athena import AthenaConnection
from functions import *


class AthenaWriter:

    def createExternalTableSql(self, _schema, table_name, partition_key, location):

        schemaSql = ddl_schemaString(_schema, athena_type_mappings, 'string', False, partition_key, 'Athena')
        sql_create = """CREATE EXTERNAL TABLE IF NOT EXISTS {} ({})\n     
        PARTITIONED BY ( {} string) 
        ROW FORMAT SERDE 'org.apache.hadoop.hive.ql.io.parquet.serde.ParquetHiveSerDe' 
        STORED AS INPUTFORMAT 'org.apache.hadoop.hive.ql.io.parquet.MapredParquetInputFormat' 
        OUTPUTFORMAT 'org.apache.hadoop.hive.ql.io.parquet.MapredParquetOutputFormat'
        LOCATION 's3://{}'""".format(table_name, schemaSql, partition_key, location)

        sql_create = re.sub(',\s\)*$', ')', sql_create)  # remove the last ,
        return sql_create

    def write_table(self, _df, db_options):
        audit_process_status = 'success'
        connection = self.conn
        athena_connection = AthenaConnection(connection, self.athena)
        add = None
        drop = None
        data_bucket_name = connection['data_bucket_name']
        location = "{}/{}".format(data_bucket_name, db_options['table_name'])
        database = db_options['table_name'].split(".")[0]

        try:
            partition_cols = db_options['partition_key'].split(",")

            if db_options['partition_key'] != 'null':
                PartitionKeysList = db_options['partition_key'].lower().split(",")
                partitionlist = _df.select(*PartitionKeysList).distinct().collect()
                print(partitionlist)
                drop, add = get_actions(connection, partitionlist, db_options['partition_key'], db_options['table_name'])

            write_to_parquet(_df, db_options['table_name'], data_bucket_name, db_options['mode'], partition_cols)

            create_database = "CREATE DATABASE IF NOT EXISTS {};".format(database)
            #res = athena_connection.execute_actions(create_database, database)

            if 'pre_action' in db_options:
                if (db_options['pre_action'] != '') & ( db_options['pre_action'] != None):
                    res = athena_connection.execute_actions(to_fStrings(db_options['pre_action']), database)
                    print(db_options['pre_action'])

            sql = self.createExternalTableSql(_df.schema, db_options['table_name'], db_options['partition_key'],
                                              location)
            res = athena_connection.execute_actions(to_fStrings(sql), database)
            print(sql)

            #if drop != None :
                #print(drop)
                #res = athena_connection.execute_actions(to_fStrings(drop), database)

            if add != None:
                print(add)
                res = athena_connection.execute_actions(to_fStrings(add), database)

            if 'post_action' in db_options:
                if ( db_options['post_action'] != '') & ( db_options['post_action'] != None):
                    res = athena_connection.execute_actions(to_fStrings(db_options['post_action']), database)
                    print(db_options['post_action'])

        except Exception as e:
            audit_process_status = 'error'
            print(e)

        return audit_process_status

    def __init__(self, conn, athena):
        self.conn = conn
        self.athena = athena