import boto3


class AthenaConnection:

    def execute_actions(self, query, database):
        response = None
        s3_output = 's3://{}'.format(self.conn['s3_output'])  # results OutputLocation for run
        workgroup = self.conn['workgroup']
        print(s3_output)
        print('workgroup:{}'.format(workgroup))
        print('database:{}'.format(database))
        try:
            response = self.athena.start_query_execution(
                QueryString=query,
                WorkGroup=workgroup,
                QueryExecutionContext={
                    'Database': database
                },
                ResultConfiguration={
                    'OutputLocation': s3_output
                }
            )
            print('Execution ID: ' + response['QueryExecutionId'])
            #state = self.athena_get_query_execution(response['QueryExecutionId'])
            #print(state)
        except Exception as e:
            print('Athena Error: {}'.format(e))
        return response

    def athena_get_query_execution(self, execution_id):
        state = 'RUNNING'
        while state in ['RUNNING', 'QUEUED']:
            response = self.athena.get_query_execution(QueryExecutionId=execution_id)
            if 'QueryExecution' in response and 'Status' in response['QueryExecution'] and 'State' in \
                    response['QueryExecution']['Status']:
                state = response['QueryExecution']['Status']['State']
                #print(response)
        return state

    def __init__(self, conn, athena):
        self.conn = conn
        self.athena = athena
