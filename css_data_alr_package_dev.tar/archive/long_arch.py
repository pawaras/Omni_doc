import boto3
import pandas as pd
import csv
#import pandasql
import io
#from toolz import interleave
import os
import sqlalchemy
import psycopg2
import json
import datetime
import time
import logging
import re
from io import StringIO
import uuid
import sys

from pyspark import SparkConf
from pyspark.sql import SparkSession



logger = logging.getLogger('adhoc_lambda')


def setup_boto3(region):
    s3_client = boto3.client('s3')
    s3_resource = boto3.resource('s3')
    athena = boto3.client('athena', region_name=region)
    sm_client = boto3.client('secretsmanager', region_name=region)
    lm_client = client = boto3.client('lambda', region_name=region)
    return s3_client, s3_resource, athena, sm_client, lm_client

def put_error_cloudwatch(region, log_group, error_msg):
    client = boto3.client('logs', region_name=region)

    logGroupName = log_group
    logStreamName = f"{log_group}-" + datetime.datetime.utcnow().__str__().replace(":", "")

    log_stream = client.create_log_stream(
        logGroupName=logGroupName,
        logStreamName=logStreamName
    )

    log_event = client.put_log_events(
        logGroupName=logGroupName,
        logStreamName=logStreamName,
        logEvents=[
            {
                'timestamp': int(time.time() * 1000),
                'message': str(error_msg)
            }
        ]
    )

def send_sns(region,Topic, Message, Subject='Error'):

    try:
        sns = boto3.client('sns', region_name=region)
        response = sns.publish(
            TopicArn=Topic,
            Message=str(Message),
            Subject=Subject
        )
        logger.info("response SNS: {}".format(response))
    except Exception as e:
        logger.info('Error SNS: {}'.format(e))
    return response

def write_error(region_name, Topic, cw_log_group, eSubjectName ,eerror):
    if Topic != None:
        send_sns(region_name, Topic, eerror, eSubjectName[:100])

    if cw_log_group != None:
        put_error_cloudwatch(region_name, cw_log_group, eerror)

def sm_connect(sm_client, connection_key):
    get_secret_value_response = sm_client.get_secret_value(
        SecretId=connection_key
    )

    secretDict = json.loads(get_secret_value_response['SecretString'])

    host = secretDict['alr_validation']['url']
    username: str = secretDict['alr_validation']['username']
    password:str = secretDict['alr_validation']['password']
    port = secretDict['alr_validation']['port']
    db = secretDict['alr_validation']['db_name']
    schema = secretDict['alr_validation']['schema']
    topic = secretDict['alr_validation']['topic']
    cw_log_group = secretDict['alr_validation']['error_log_group']

    connection = f"postgresql://{username}:{password}@{host}:{port}/{db}"


    return connection, topic, schema, cw_log_group

def contstruct_successfull_msg(table,ts,schema):

    v_sql = f"select number_of_records,trans_date,table_name from {schema}.etl_archive_log where trans_date = '{ts}' "

    print(v_sql)

    resutls = pd.read_sql(v_sql ,engine)



    tableToProcess = list(resutls['table_name'])
    record:list = []

    for i, item in enumerate(tableToProcess):

        text: str
        cnt:int  = resutls.loc[i,'number_of_records']
        t_date:str = resutls.loc[i,'trans_date']
        table_name = resutls.loc[i,'table_name']
        #record = f"{cnt} records were inserted/updated in {table_name} on transanction date: {t_date} "
        #record.append(f"{cnt} records were inserted/updated in {table_name} on transanction date: {t_date} ")
        if i == 0:
            record = [f"{cnt} records have been archived from {table_name} on archival date: {t_date} "]
        else:
            record.append(f"{cnt} records have been archived from {table_name} on archival date: {t_date} ")



    message:str = ""

    for i in range(len(record)):
        print(record[i])
        text = record[i]
        message +=  text + '\n'



    return message

def audit_process(schema,v_sql,table,ts):

    audit_sql = f"select count(*) from ({v_sql}) a"

    trans_id = uuid.uuid4().hex

    resutls = pd.read_sql(audit_sql ,engine)


    rec_cnt = resutls.iloc[0,0]
    print(f"record count: {rec_cnt}")

    rec_cnt = resutls.iloc[0,0]

    if rec_cnt is None:
        print(f"rec_cnt is empty")
        rec_cnt = 0

    print(f"record count: {rec_cnt}")

    if rec_cnt == 0:
        print("archive is false")
    else:
        v_sql = f"Insert into {schema}.etl_archive_log values('{trans_id}','{table}','{rec_cnt}', '{ts}','{ts}')"
        print(v_sql)

    with engine.begin() as con:
        con.execute(v_sql)

    return rec_cnt



def backup_table(table:str,schema:str):
    v_sql:str = f"create table {table}_bck as (select * from {schema}.{table})"
    print(v_sql)

    with engine.begin() as con:
            con.execute(v_sql)

def drop_table(table:str,schema:str):
    v_sql:str = f"DROP TABLE IF EXISTS {table}_bck CASCADE;"

    with engine.begin() as con:
        con.execute(v_sql)



def writeToFILe(df,bucket,table,rltv_mo,tss):
    print(f"write to file {bucket}/{table}/{rltv_mo}")

    csv_buffer = StringIO()
    df.to_csv(csv_buffer, index=False, header=True)
    s3_resource.Object(bucket, f"{table}_{rltv_mo}_{tss}.csv").put(Body=csv_buffer.getvalue(),ACL='bucket-owner-full-control')



def dataArchive(dt:str,schema:str,bucket:str,region_name:str,topic:str,tsMon,tss):
    print(dt)
    
    ts = dt.strftime("%Y-%m-%d %H:%M:%S")
    control_df = pd.read_sql('select * from '+ schema +".etl_tables_to_arch",engine)
    tableToProcess = list(control_df['table_nm'])
    backup_df = pd.read_sql('select distinct table_nm from '+ schema +".etl_tables_to_arch",engine)
    tableToBackup = list(backup_df['table_nm'])
    print(tableToBackup)


    for i in tableToBackup:
        table:str = i
        drop_table(table,schema)

    for i in tableToBackup:
        table:str = i
        backup_table(table,schema)


    trans_id= re.sub('[^0-9]', '', str(ts))


    print(tableToProcess)
    message = None
    print(message)
    for i, item in enumerate(tableToProcess):
        try:
            table:str = item
            print(table)


            v_sql_f = control_df.iloc[i]['sql_arch']
            v_sql = v_sql_f.format(schema)
            print(v_sql)

            print("get relative month")
            trans_df = pd.read_sql(v_sql,engine)

            if trans_df.empty:
               print('DataFrame is empty!')               
            else:
                 if table == 'study_premise' or  table == 'study' or table == 'archive':
                      rltv_mo = tsMon
                 else:
                      rltv_mo = trans_df.iloc[0]['rltv_mo']

                 print(rltv_mo)

                 rec_cnt = audit_process(schema,v_sql,table,ts)                 

                 writeToFILe(trans_df,bucket,table,rltv_mo,tss)
                 v_sql_f = control_df.iloc[i]['sql_del']
                 v_sql = v_sql_f.format(schema)
                 print(v_sql)
                 with engine.begin() as con:
                      con.execute(v_sql)

                 message:str = contstruct_successfull_msg(table,ts,schema)                 





        except Exception as e:
            print(f"Error occured {e} in table {table}")
            logger.info('Error Archive procedure: {}'.format(e))
            eerror = f"Error occurred {e} in table {table}"
            eSubjectName = 'Archival process Error'
            write_error(region_name, Topic, cw_log_group, eSubjectName, eerror)
            # send_sns(region_name,Topic,context,Subject='Archival process Error')
            sys.exit(1)
    if message == None:
        send_sns(region_name, Topic,"No data to archive", Subject='Archival process ran successfully')
    else:
        send_sns(region_name,Topic,message,Subject='Archival process ran successfully')


def get_spark_env():
    conf = SparkConf().set("spark.jars", "/home/hadoop/jars/postgresql-42.2.12.jar,/home/hadoop/jars/mssql-jdbc-8.2.2.jre8.jar,/home/hadoop/jars/cobol-parser-0.2.5.jar,/home/hadoop/jars/spark-cobol-0.2.5.jar,/home/hadoop/jars/scodec-core_2.11-1.10.3.jar,/home/hadoop/jars/scodec-bits_2.11-1.1.4.jar")\
        .set('spark.executor.memory', '37G')\
        .set('spark.driver.memory', '37G') \
        .set("spark.executor.memoryOverhead", "5g") \
        .set('spark.kryoserializer.buffer.max', '128m')

    spark = SparkSession.builder. \
        appName("archive"). \
        config(conf=conf). \
        getOrCreate()
    return spark

try:
    dt = datetime.datetime.now()
    ts = dt.strftime("%Y-%m-%d-%H:%M:%S")
    print(ts)
    region_name:str = 'us-east-1'
    s3_client, s3_resource, athena, sm_client, lm_client = setup_boto3(region_name)
    connection, Topic, schema, cw_log_group = sm_connect(sm_client,"2MPV-LO174-ALR-sm")
    engine = sqlalchemy.create_engine(connection)
    print(connection)

    bucket = '2epv-lo174-archive-prod-infrequentaccess-s3'

    tsMon = dt.strftime("%Y%m")

    spark = get_spark_env()

    dataArchive(dt,schema,bucket,region_name,Topic,tsMon,ts)
except Exception as e:
    logger.info('Error Archive procedure: {}'.format(e))
    eerror = f"Error occurred in Archive process {e} "
    eSubjectName = 'Archival process Error'
    write_error(region_name, Topic, cw_log_group, eSubjectName, eerror)
    sys.exit(1)

