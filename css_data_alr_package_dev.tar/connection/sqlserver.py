import pyodbc
import re


class SQLServerConnection:

    def get_connection(self):
        connection = self.conn
        c_conn = None
        driver = 'ODBC Driver 17 for SQL Server'
        try:
            regex_str = r".*:\/\/([^:\/\\]+)?(.+)?"
            match = re.search(regex_str, connection['url'])
            host = match.group(1)

            regex_str = r'database=([_a-zA-Z]+)'
            re_database = re.search(regex_str, match.group(2))
            db_name = re_database.group(1)

            conn_str = "DRIVER={%s};SERVER=%s;DATABASE=%s;UID=%s;PWD=%s" % (
                driver, host, db_name, connection['username'], connection['password']) # pragma: allowlist secret

            c_conn = pyodbc.connect(conn_str)

        except Exception as e:
            print(e)
            print("ERROR: Unexpected error: Could not connect to the instance.")
            raise e
        return c_conn

    def execute_actions(self, sql):
        status = False
        try:
            c_conn = self.get_connection()
            cursor = c_conn.cursor()
            cursor.execute(sql)  # review parameters
            c_conn.commit()
            status = True
        #except pyodbc.DatabaseError as e:
            #if c_conn:
                #c_conn.rollback()
            #print("Error=>" + str(e))
        except Exception as e:
            print("Error=>" + str(e))
        finally:
            cursor.close()
            c_conn.close()
        return status

    def execute_sql(self, sql):
        _records = None
        try:
            c_conn = self.get_connection()
            cursor = c_conn.cursor()
            cursor.execute(sql)
            _records = cursor.fetchall()
            c_conn.commit()
        except pyodbc.DatabaseError as e:
            if c_conn:
                c_conn.rollback()
            print("Error=>" + str(e))
        except Exception as e:
            print("Error=>" + str(e))
        finally:
            cursor.close()
            c_conn.close()
        return _records

    def __init__(self, conn):
        self.conn = conn
