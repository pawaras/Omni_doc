import psycopg2
import re


class PostgresSQLConnection:

    def get_connection(self):
        connection = self.conn
        port = '5432'
        try:
            regex_str = r".*:\/\/([^:\/]+)?(.+)?"
            match = re.search(regex_str, connection['url'])
            host = match.group(1)

            regex_str = r'([_a-zA-Z]+)'
            re_database = re.search(regex_str, match.group(2))
            db_name = re_database.group(1)

            regex_str = r'([\d]+)'
            re_port = re.search(regex_str, match.group(2))
            if re_port != None: port = re_port.group(1)

            c_conn = psycopg2.connect(host=host, user=connection['username'], password=connection['password'], database=db_name, port=port) # pragma: allowlist secret
        except Exception as e:
            print(e)
            print("ERROR: Unexpected error: Could not connect to the instance.")
            raise e
        return c_conn


    def execute_actions(self, sql):
        status = False
        try:
            c_conn = self.get_connection()
            cursor = c_conn.cursor()
            cursor.execute(sql)  # review parameters
            c_conn.commit()
            status = True
        except psycopg2.DatabaseError as e:
            if c_conn:
                c_conn.rollback()
            print("Error=>" + str(e))
        except Exception as e:
            print("Error=>" + str(e))
        finally:
            cursor.close()
            c_conn.close()
        return status


    def execute_sql(self, sql):
        _records = None
        try:
            c_conn = self.get_connection()
            cursor = c_conn.cursor()
            cursor.execute(sql)
            _records = cursor.fetchall()
            c_conn.commit()
        except psycopg2.DatabaseError as e:
            if c_conn:
                c_conn.rollback()
            print("Error=>" + str(e))
        except Exception as e:
            print("Error=>" + str(e))
        finally:
            cursor.close()
            c_conn.close()
        return _records


    def __init__(self, conn):
        self.conn = conn