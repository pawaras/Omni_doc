from pyhive import hive
import re
import pandas as pd
from datetime import datetime
#import databricks.koalas as ks
from multiprocessing.dummy import Pool as ThreadPool
import multiprocessing as mp

class HiveConnection:

    def get_connection(self):
        connection = self.conn
        c_conn = None
        try:
            host_name = connection['url']
            port = connection['port']
            username = connection['username']
            database = connection['database']  #"default"
            c_conn = hive.Connection(host=host_name, port=port, username=username, database=database, auth='KERBEROS', kerberos_service_name="hive")
        except Exception as e:
            print(e)
            print("ERROR: Unexpected error: Could not connect to the instance.")
            raise e
        return c_conn


    def execute_sql_to_rows(self, sql): # parameters sql
        try:
            c_conn= self.get_connection()
            print(datetime.strptime(str(datetime.now().strftime('%Y-%m-%d-%H:%M:%S')), '%Y-%m-%d-%H:%M:%S'))
            cursor = c_conn.cursor()
            cursor.execute(sql)
            names = [x[0] for x in cursor.description]
            rows = cursor.fetchall()
            c_conn.commit()
            print(datetime.strptime(str(datetime.now().strftime('%Y-%m-%d-%H:%M:%S')), '%Y-%m-%d-%H:%M:%S'))
        except Exception as e:
            print("Error=>" + str(e))
        finally:
            cursor.close()
            c_conn.close()
        return names, rows





    def process_chunk(self, chunk):
        return chunk




    def __init__(self, conn):
        self.conn = conn