from pyspark.sql import SparkSession
from pyspark.sql.types import ArrayType, StructField, StructType, StringType, IntegerType, DecimalType, FloatType, \
    LongType, DateType, TimestampType, DoubleType
from pyspark.sql.functions import udf, collect_list, struct, explode, pandas_udf, PandasUDFType, col
from decimal import Decimal
import random
import pandas as pd
import numpy as np
import datetime
import pandasql as ps
import io
from io import StringIO  # python3; python2: BytesIO
import boto3
import os
import datetime
from datetime import date
from datetime import datetime
import time
import csv
import argparse
from datetime import timedelta
from pyspark.sql import SparkSession
import sys
from pyspark.sql.functions import *
from pyspark.sql import *
import paramiko
import json
import psycopg2
import sqlalchemy
from pyspark.sql import DataFrame
import logging

logger = logging.getLogger('lse process')


def get_parameter_options(parser, args):
    parsed, extra = parser.parse_known_args(args[1:])
    if extra:
        print('unrecognized arguments:', extra)
    return vars(parsed)


def parse_arguments(args):
    parser = argparse.ArgumentParser(prog=args[0])
    # parser.add_argument('-f', '--input_file_name', required=False, help='')
    # parser.add_argument('-fp', '--input_file_name_fpl', required=False, help='')
    # parser.add_argument('-fg', '--input_file_name_ge', required=False, help='')
    parser.add_argument('-l', '--process_run_date', required=False, help='process_run_date')
    parser.add_argument('-p', '--process_type', required=False, help='process_type')
    parser.add_argument('-d', '--bill_date', required=False, help='bill_date')
    parser.add_argument('-b', '--rltv_mo', required=False, help='rltv_mo')
    parser.add_argument('-r', '--region_name', required=False, help='AWS Region name')
    parser.add_argument('-s', '--connection_name', required=True, help='AWS Secrets Manager')
    parser.add_argument('-k', '--s3sftp', required=True, help='aws s3 sftp')
    parser.add_argument('-t', '--sns_topic', required=False, help='sns Topic')
    parser.add_argument('-g', '--cw_log_group', required=False, help='CloudWatch')
    # parser.add_argument('-d', '--dag_name', required=False, help='Dag Name')
    # parser.add_argument('-c', '--company_name', required=True, help='company_name')
    # parser.add_argument('-c', '--company_name', required=True, help='company_name')
    options = get_parameter_options(parser, args)
    return options


def sm_connect(sm_client, connection_key):
    get_secret_value_response = sm_client.get_secret_value(
        SecretId=connection_key
    )

    secretDict = json.loads(get_secret_value_response['SecretString'])

    sftp_host: str = secretDict['goxsa_sftp']['url']
    sftp_username: str = secretDict['goxsa_sftp']['username']
    oracle_output: str = secretDict['goxsa_sftp']['output_path']
    pckg_bucket: str = secretDict['goxsa_sftp']['package_s3']
    host = secretDict['alr_validation']['url']
    username: str = secretDict['alr_validation']['username']
    password: str = secretDict['alr_validation']['password']
    port = secretDict['alr_validation']['port']
    db = secretDict['alr_validation']['db_name']
    schema = secretDict['alr_validation']['schema']
    topic = secretDict['alr_validation']['topic']
    bucket = secretDict['alr_s3']['data_bucket_name']

    connection = f"postgresql://{username}:{password}@{host}:{port}/{db}"

    return sftp_host, sftp_username, oracle_output, connection, schema, bucket, pckg_bucket, topic


def put_error_cloudwatch(region, log_group, error_msg):
    client = boto3.client('logs', region_name=region)

    logGroupName = log_group
    logStreamName = f"{log_group}-" + datetime.utcnow().__str__().replace(":", "")

    log_stream = client.create_log_stream(
        logGroupName=logGroupName,
        logStreamName=logStreamName
    )

    log_event = client.put_log_events(
        logGroupName=logGroupName,
        logStreamName=logStreamName,
        logEvents=[
            {
                'timestamp': int(time.time() * 1000),
                'message': str(error_msg)
            }
        ]
    )

def send_sns(region, Topic, Message, Subject='Error'):
    logger = logging.getLogger('readiness')

    try:
        sns = boto3.client('sns', region_name=region)
        response = sns.publish(
            TopicArn=Topic,
            Message=str(Message),
            Subject=Subject
        )

        logger.info("response SNS: {}".format(response))

    except Exception as e:
        logger.info('Error SNS: {}'.format(e))

    return response

def write_error(region_name, Topic, cw_log_group, eSubjectName ,eerror):
    if Topic != None:
        send_sns(region_name, Topic, eerror, eSubjectName[:100])

    if cw_log_group != None:
        put_error_cloudwatch(region_name, cw_log_group, eerror)


def setup_boto3(region):
    s3_client = boto3.client('s3')
    s3_resource = boto3.resource('s3')
    athena = boto3.client('athena', region_name=region)
    sm_client = boto3.client('secretsmanager', region_name=region)

    return s3_client, s3_resource, athena, sm_client


def Create_intervals(input_file_name_fpl: str, input_file_name_ge: str):
    window_1 = Window.partitionBy(
        ['premiseid', 'accountid', 'meterid', 'channel', 'spi', 'metermtply', 'date_interval']).orderBy(
        'read_strt_time').rowsBetween(Window.unboundedPreceding, Window.currentRow)
    window_2 = Window.partitionBy(
        ['premiseid', 'accountid', 'meterid', 'channel', 'spi', 'metermtply', 'date_interval']).orderBy(
        desc('read_strt_time'))
    win = Window.partitionBy(['premiseid', 'accountid', 'meterid', 'channel', 'spi', 'metermtply'])

    if input_file_name_fpl != None and input_file_name_ge != None:
        df1 = spark.read.csv(input_file_name_fpl.strip(), inferSchema=True, header=True)
        df1 = df1.withColumn('premiseid', lpad(df1.premiseid, 9, '0'))
        df2 = spark.read.csv(input_file_name_ge.strip(), inferSchema=True, header=True)
        df = df1.union(df2)
        print("DataFrame was merged")
    elif input_file_name_fpl != None:
        print(f"input_file_name: {input_file_name_fpl}")
        df1 = spark.read.csv(input_file_name_fpl.strip(), inferSchema=True, header=True)
        df1 = df1.withColumn('premiseid', lpad(df1.premiseid, 9, '0'))
        # df1 = df1.withColumn("company",lit('FPL'))
        df = df1
        df1.show()
    elif input_file_name_ge != None:
        print(f"input_file_name: {input_file_name_ge}")
        df2 = spark.read.csv(input_file_name_ge.strip(), inferSchema=True, header=True)
        df = df2
    else:
        print("dataframes are empy")

    df = df.na.fill(value=0, subset=["wc_dist"])
    df.withColumn("wc_dist", df.wc_dist.cast(IntegerType()))
    df.withColumn("zipcode", df.zipcode.cast(IntegerType()))

    df.createOrReplaceTempView('intervals')
    spark.sql('select distinct company from intervals').show()

    df = df.withColumn('date_interval', to_date(col("read_strt_time"), "yyyy-MM-dd"))

    df = df.withColumn('status', when(col('kwh') < 0, lit('G')).otherwise(col('status')))
    df = df.withColumn('status', when(col('status').isNull(), lit(' ')).otherwise(col('status')))


    df = df.withColumn('space_column', lit(''))
    df = df.withColumn('kwh', when(col('kwh').isNull(), lit(0)).otherwise(col('kwh')))
    df = df.withColumn('kwh', round(col('kwh'), 4))
    df = df.withColumn('kwh', df.kwh.cast(DecimalType(12, 4)))

    df = df.withColumn('max_read_strt_time', max('read_strt_time').over(win))
    df = df.withColumn('min_read_strt_time', min('read_strt_time').over(win))

    df = df.select('company', 'premiseid', 'accountid', 'metertype', 'metermtply', 'meterid', 'channel', 'uom', 'spi',
                   'customer',
                   'ratecode', 'zipcode', 'billkwh', 'wc_dist', 'date_interval', 'read_strt_time', 'kwh', 'status',
                   'read_strt_time', 'max_read_strt_time', 'min_read_strt_time',
                   concat_ws(",", array(["kwh", "status", "space_column"])).alias("tuple"))

    df = df.withColumn("row_number", row_number().over(window_2))
    df = df.withColumn("intervals_to_print", collect_list(col("tuple")).over(window_1))
    df = df.withColumn("intervals_to_print", trim(concat_ws(",", concat(df.intervals_to_print, array(lit(""))))))

    df = df.filter(col('row_number') == 1).select('company', 'premiseid', 'accountid', 'metertype', 'metermtply',
                                                  'meterid',
                                                  'channel', 'uom', 'spi', 'customer', 'ratecode', 'zipcode', 'billkwh',
                                                  'wc_dist', 'date_interval', 'intervals_to_print',
                                                  'max_read_strt_time', 'min_read_strt_time')

    return df


schema = StructType([
    StructField('output', StringType(), False)
])


def write_to_s3():
    s3_client = boto3.client('s3')
    s3 = boto3.resource('s3')

    dest_file: str = f'lse/{output_file}'
    target_bucket: str = s3sftp.strip()
    s3_resource.Object(target_bucket, dest_file).copy_from(CopySource=f"{bucket}/{output_file}")
    s3_resource.Object(bucket, output_file).delete()

    object = s3_resource.Bucket(target_bucket).Object(dest_file)
    object.Acl().put(ACL='bucket-owner-full-control')
    print("file moved to S3 SFTP")


def sftp():
    try:
        keyFile = "package/ttt"
        obj = s3_client.get_object(Bucket=pckg_bucket, Key=keyFile)
        decodeKey = obj['Body'].read().decode('utf-8')

        key = paramiko.RSAKey.from_private_key(StringIO(decodeKey))
        client = paramiko.SSHClient()
        client.load_system_host_keys()
        client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
        transport = paramiko.Transport((sftp_host, int(port)))
        transport.connect(username=sftp_username, pkey=key)

        sftp = paramiko.SFTPClient.from_transport(transport)
        # sftp.chdir(path=oracle_output + '/' + company_name.strip())
        sftp.chdir(path=oracle_output)
        print(sftp.listdir(path='.'))

        with sftp.open(output_file, 'wb', 32768) as f:
            s3_client.download_fileobj(bucket, output_file, f)


    except Exception as e:
        print("sftp failed in lse process")
        eerror: str = f"LSE process failed to write to Oracle server {e}\n Please get LSE file from S3 SFTP"
        eSubjectName = "lse sftp error"
        write_error(region_name, topic, cw_log_group, eSubjectName, eerror)


# @pandas_udf(schema, PandasUDFType.GROUPED_MAP)
def create_header1(pdf):
    pdf["wc_dist"] = pdf["wc_dist"].replace(0, "")
    pdf['wc_dist'] = pdf['wc_dist'].astype('str')
    pdf['billkwh'] = pdf['billkwh'].astype('str')
    pdf["customer"] = pdf["customer"].str[:20]
    pdf["customer"] = pdf["customer"].str.pad(20, side='right')
    pdf["wc_dist"] = pdf["wc_dist"].str.pad(9, side='right')
    pdf['metertype'] = pdf['metertype'].astype(str)
    pdf["metertype"] = pdf["metertype"].str.pad(8, side='right')
    pdf["billkwh"] = pdf["billkwh"].str.pad(10, side='right')
    pdf['ratecode'] = pdf['ratecode'].astype('str')
    pdf["ratecode"] = pdf["ratecode"].str.pad(12, side='right')

    # ---- PART 1 - .LSE FILE HEADER CREATION START ----

    # create iteration looping context
    prem_list = pdf['premiseid'].unique()

    ind = 0
    cnt = 1

    data_toList = ps.sqldf("select distinct premiseid,channel,meterid,accountid, spi, metermtply from pdf")

    list_prem = data_toList['premiseid']
    list_channel = data_toList['channel']
    list_meterid = data_toList['meterid']
    list_accountid = data_toList['accountid']
    list_spi = data_toList['spi']
    list_metermtply = data_toList['metermtply']

    iterTupple = list(zip(list_prem, list_channel, list_meterid, list_accountid, list_spi, list_metermtply))

    for i in iterTupple:
        cur_premise = i[0]
        channel = i[1]
        meterid = i[2]
        accountid = i[3]
        spi = i[4]
        metermtply = i[5]

        print(cur_premise)
        print(channel)

        meter_df_int = pdf.query(
            'premiseid == @cur_premise & channel == @channel & meterid == @meterid & accountid == @accountid & spi == @spi & metermtply == @metermtply')

        # filter proceding operation to single premise
        df_start_stop_i = pdf.query(
            'premiseid == @cur_premise & channel == @channel & meterid == @meterid & accountid == @accountid & spi == @spi & metermtply == @metermtply')
        sort_code1 = '00000001'  # specific .lse row header value

        # format time from input df's to match .lse convention
        # meter_df_int['premiseid'] = meter_df_int['premiseid'].apply(lambda x: '{0:0>9}'.format(x))
        premise = meter_df_int.iloc[0]['premiseid']
        dt = meter_df_int.iloc[0]['min_read_strt_time']
        start_time = int(dt.strftime("%Y%m%d%H%M%S"))
        dt = meter_df_int.iloc[0]['max_read_strt_time']
        end_time_int = str(dt.strftime("%Y/%m/%d %H:%M:%S"))
        date_format_str = '%Y/%m/%d %H:%M:%S'
        given_time = datetime.strptime(end_time_int, date_format_str)
        spi = meter_df_int.iloc[0]['spi']

        if spi == 900:
            n = 14
            s = 59
        elif spi == 3600:
            n = 59
            s = 59
        else:
            print("spi is invalid")
            n = 14
            s = 59

        final_time = given_time + timedelta(minutes=n, seconds=s)
        end_time = int(final_time.strftime("%Y%m%d%H%M%S"))

        # collect other items that need to be in header section
        # other items will need to be added during build
        channel = meter_df_int.iloc[0]['channel']

        DST_Participant_Flag = 'Y'  # replace with dynamic ref
        Invalid_Record_Flag = 'Y'  # replace with dynamic ref

        ## ALL ITEMS ARE COLLECTED AND APPENDED TO THE HEADER
        header1 = pd.DataFrame(
            [[sort_code1, premise, channel, start_time, end_time, DST_Participant_Flag, Invalid_Record_Flag]],
            columns=['sort_code1', 'premise', 'channel', 'start_time', 'end_time', 'DST_Participant_Flag',
                     'Invalid_Record_Flag'])

        dfpl = header1.values.tolist()

        d = {}

        for x in range(0, len(dfpl[0])):
            d[f"field{x}"] = dfpl[0][x]

        testList = list(d.values())
        output = ""

        for item in testList[:-1]:
            output += str(item) + ","

        output += testList[-1]

        head1 = pd.DataFrame([[output]], columns=['output'])

        # ===========================Header 2 logic

        sort_code2 = '00000002'  # specific .lse row header value

        dfi = pdf.query(
            "premiseid == @cur_premise & channel == @channel  & meterid == @meterid & accountid == @accountid &  spi == @spi & metermtply == @metermtply")  # filter df to single premise

        # collect other items that need to be in header section
        meter_start_reading = 0
        meter_stop_reading = 0
        meter_multiplier = dfi.iloc[0]['metermtply']
        meter_offset = 0
        pulse_multiplier = 1
        pulse_offset = 0
        seconds_per_interval = spi

        uom_df = ps.sqldf("select case when uom = 'INTKW' then '02' else '01' end uom from dfi")

        # uom = uom_df.iloc[0]['uom']
        uom = '01'  # kWh = 01 (aggregates with sum); kW = 02 (aggregates with average)
        basic_unit_code = ''  # Reserved for future Oracle use
        time_zone = 10  # EST = 10; Pacific = 16
        population = 0
        weight = 0
        tz_stand_name = ''

        ##ITEMS ARE COLLECTED AND APPENDED TO THE HEADER

        header2 = pd.DataFrame([[sort_code2, meter_start_reading, meter_stop_reading, meter_multiplier, meter_offset,
                                 pulse_multiplier, pulse_offset, seconds_per_interval, uom, basic_unit_code,
                                 time_zone]],
                               columns=['sort_code2', 'meter_start_reading', 'meter_stop_reading', 'meter_multiplier',
                                        'meter_offset', 'pulse_multiplier', 'pulse_offset', 'seconds_per_interval',
                                        'uom', 'basic_unit_code', 'time_zone'])

        dfpl = header2.values.tolist()

        d = {}

        for x in range(0, len(dfpl[0])):
            d[f"field{x}"] = dfpl[0][x]

        testList = list(d.values())
        output = ""

        for item in testList[:-1]:
            output += str(item) + ","

        output += str(testList[-1])

        head2 = pd.DataFrame([[output]], columns=['output'])

        # ==============================Header3 logic
        sort_code3 = '00000003'  # specific .lse row header value
        customer = dfi.iloc[0]['customer']
        dfi['accountid'] = dfi['accountid'].apply(lambda x: '{0:0>10}'.format(x))
        dfi['ratecode'] = dfi['ratecode'].apply(lambda x: '{0:0>12}'.format(x))
        account = dfi.iloc[0]['accountid']
        ratecode = dfi.iloc[0]['ratecode']
        zipcode = dfi.iloc[0]['zipcode']
        wc_district = dfi.iloc[0]['wc_dist']
        metertype = dfi.iloc[0]['metertype']
        billkwh = dfi.iloc[0]['billkwh']

        descriptor = str(customer) + ' ' + str(account) + ' ' + str(ratecode) + ' ' + str(zipcode) + ' ' + str(
            metertype) + ' ' + str(billkwh) + ' ' + str(wc_district)

        header3 = pd.DataFrame([[sort_code3, descriptor]], columns=['sort_code3', 'descriptor'])
        dfpl = header3.values.tolist()

        for item in dfpl:
            field1 = item[0]
            field2 = item[1]

            output = str(field1) + "," + str(field2)
            print(output)

        head3 = pd.DataFrame([[output]], columns=['output'])

        # ====================Header4 logic

        sort_code4 = '00000004'  # specific .lse row header value
        ts = ''
        origin = 'M'  # replace with dynamic ref

        header4 = pd.DataFrame([[sort_code4, ts, origin]], columns=['sort_code4', 'ts', 'origin'])
        dfpl = header4.values.tolist()

        for item in dfpl:
            field1 = item[0]
            field2 = item[1]
            field3 = item[2]

            output = str(field1) + "," + str(field2) + "," + str(field3)
            print(output)

        head4 = pd.DataFrame([[output]], columns=['output'])

        # ===================================Create Data Logic
        initial_value = 10000000  # first day in .lse file begins with this always

        #     #each day after that is just incremented by 1 perpetually
        dfp = dfi
        dfp['counter'] = range(initial_value, len(dfp) + initial_value)
        first_column = dfp['counter']
        dfp.drop(labels=['counter'], axis=1, inplace=True)
        dfp.insert(0, 'counter', first_column)

        dfp_intervals = ps.sqldf("select counter, intervals_to_print from dfp")

        dfpl = dfp_intervals.values.tolist()

        column_names = ["output"]
        dfpl_list = []

        for item in dfpl:
            counter = item[0]
            interval = item[1]
            output = f"{counter},{interval}"

            dfpl_list.append(output)

        data_df = pd.DataFrame(dfpl_list, columns=column_names)

        if cnt == 1:
            header_df = head1
            header_df = header_df.append(head2, ignore_index=True)
            header_df = header_df.append(head3, ignore_index=True)
            header_df = header_df.append(head4, ignore_index=True)
            header_df = header_df.append(data_df, ignore_index=True)
        else:
            header_df = header_df.append(head1, ignore_index=True)
            header_df = header_df.append(head2, ignore_index=True)
            header_df = header_df.append(head3, ignore_index=True)
            header_df = header_df.append(head4, ignore_index=True)
            header_df = header_df.append(data_df, ignore_index=True)

        cnt = cnt + 1

    return header_df


if __name__ == "__main__":
    options = parse_arguments(sys.argv)
    process_type = options.get('process_type').strip()
    bill_date = options.get('bill_date') or None
    process_run_date = options.get('process_run_date') or str((datetime.now()).strftime('%Y%m%d'))
    rltv_mo = options.get('rltv_mo') or None
    if rltv_mo != None:
        rltv_mo = rltv_mo.strip()
    else:
        bill_date = bill_date.strip()
    connection_name = options.get('connection_name').strip()
    region_name = options.get('region_name') or 'us-east-1'
    s3sftp: str = options.get('s3sftp').strip()
    cw_log_group = options.get('cw_log_group') or None
    spark = SparkSession.builder.appName('lse').getOrCreate()
    spark.conf.set("spark.sql.session.timeZone", "America/New_York")
    s3_resource = boto3.resource('s3')

    if cw_log_group != None: cw_log_group = cw_log_group.strip()

    try:

        s3_client, s3_resource, athena, sm_client = setup_boto3(region_name)

        sftp_host, sftp_username, oracle_output, connection, psql_schema, bucket, pckg_bucket, topic = sm_connect(
            sm_client, connection_name)

        if topic != None: topic = topic.strip()
        port: int = 22
        print(pckg_bucket)
        # topic: str = "arn:aws:sns:us-east-1:977465404123:2fnv-lo174-sns-topic"

        lse_bucket = s3_resource.Bucket(bucket)
        input_file_name_ge: str = None
        input_file_name_fpl: str = None

        if process_type == 'Daily':
            folder: str = "lse_daily/"
            stop = 23
        elif process_type == 'Backdated':
            folder: str = "lse_backdate/"
            stop = 22
        elif process_type == 'Reprocessed':
            folder: str = "lse_reprocess/"
            stop = 23

        for i in lse_bucket.objects.all():
            if bill_date != None and i.key[0:stop] == folder + 'FPLNW_' + bill_date:
                file_key: str = i.key[0:stop]
                input_file_name_ge: str = f"s3://{bucket}/{file_key}/"
            elif bill_date != None and i.key[0:stop + 1] == folder + 'FPL_' + bill_date:
                file_key: str = i.key[0:stop + 1]
                input_file_name_fpl: str = f"s3://{bucket}/{file_key}/"
                # print(input_file_name_fpl)
            elif rltv_mo != None:
                if i.key[0:stop] == folder + 'FPLNW_' + rltv_mo:
                    file_key: str = i.key[0:stop]
                    input_file_name_ge: str = f"s3://{bucket}/{file_key}/"
                    # print(input_file_name_ge)
                elif i.key[0:stop + 1] == folder + 'FPL_' + rltv_mo:
                    file_key: str = i.key[0:stop + 1]
                    input_file_name_fpl: str = f"s3://{bucket}/{file_key}/"

        print(input_file_name_fpl)
        print(input_file_name_ge)
        if input_file_name_fpl != None or input_file_name_ge != None:

            df = Create_intervals(input_file_name_fpl, input_file_name_ge)
            df.show()

            engine = sqlalchemy.create_engine(connection)
            v_sql: str = f"select value from {psql_schema}.variable where variableid = 'DATAPARTITION'"
            chunk_df = pd.read_sql(v_sql, engine)

            if process_type == 'Daily':
                chunk_size = 1000000
            else:
                chunk_size = int(chunk_df.iloc[0]['value'])

            prem_int_file: str = "premise_list.csv"
            df.createOrReplaceTempView('intervals')
            premise_df = spark.sql('''select distinct premiseid from intervals order by 1 ''')
            premise_cnt = spark.sql('''select count(distinct premiseid) prem_cnt from intervals''').collect()[0][0]
            s3_resource.Object(bucket, prem_int_file).delete()

            prem_pdf = premise_df.toPandas()
            prem_pdf.to_csv(f"s3://{bucket}/{prem_int_file}")
            prem_file = "premise_list.csv"

            batch_no = 1

            for chunk in pd.read_csv("s3://" + bucket + "/" + prem_file, chunksize=chunk_size):
                temp_df = spark.createDataFrame(chunk)
                df_to_run = df.join(temp_df, df.premiseid == temp_df.premiseid).select(df["*"])
                temp_df.show()

                header1 = df_to_run.groupby('premiseid').applyInPandas(create_header1, schema=schema)
                pdf = header1.toPandas()

                print((batch_no))

                csv_buffer = StringIO()
                pdf.to_csv(csv_buffer, index=False, header=False)

                s3_resource.Object(bucket, 'lse_dailyt').delete()
                s3_resource.Object(bucket, 'lse_dailyt').put(Body=csv_buffer.getvalue())

                # ==================clean the file and write to s3 bucket

                s3_client = boto3.client('s3')
                s3 = boto3.resource('s3')

                Intfilename = "lse_dailyt"
                s3_clinet = boto3.client('s3')
                response = s3_client.get_object(Bucket=bucket, Key=Intfilename)

                csv_buffer = StringIO()

                lines = response['Body'].read().splitlines(True)
                reader = csv.reader(lines)

                resp = s3_client.get_object(Bucket=bucket, Key=Intfilename)

                data = resp['Body'].read().decode('utf-8')

                data = data.replace('"', '')

                ts = time.strftime("%Y%m%d_%H%M%S")

                if rltv_mo == None:
                    if chunk_size >= premise_cnt:
                        output_file: str = f"FPL_{process_type.strip()}-AMI-Intervals_{bill_date.strip()}_{ts}.lse"
                    else:
                        output_file: str = f"FPL_{process_type.strip()}-AMI-Intervals_{bill_date.strip()}_{ts}_part_{batch_no}.lse"
                else:
                    if chunk_size >= premise_cnt:
                        output_file: str = f"{process_type.strip()}-AMI-Intervals_{rltv_mo.strip()}_{ts}.lse"
                    else:
                        output_file: str = f"{process_type.strip()}-AMI-Intervals_{rltv_mo.strip()}_{ts}_part_{batch_no}.lse"

                print(f"here is outputfile: {output_file}")

                object = s3.Object(bucket, output_file)

                txt_data = data

                result = object.put(Body=txt_data)

                res = result.get('ResponseMetadata')

                if res.get('HTTPStatusCode') == 200:
                    print('File Uploaded to S3 Successfully')
                else:
                    print('File Not Uploaded')

                #execute sftp file transfer to oracle server
                sftp()

                #write copy of the files to s3 bucket in aws enterprise account
                write_to_s3()


                batch_no += 1
                print(str(batch_no) + ' complete')
        else:
            eSubjectName = 'LSE Process: No Data'
            eerror = f"The LSE process failed due to there being no fetch data. Please check logs for fetch process and ALR for valid studies."
            write_error(region_name, topic, cw_log_group, eSubjectName, eerror)
    except Exception as e:
        print(e)
        eSubjectName = 'LSE Process Failed'
        eerror = f"Below are the failure details :\n\n{e}"
        write_error(region_name, topic, cw_log_group, eSubjectName, eerror)