import re
from connection.postgres import PostgresSQLConnection
from utils.utils import *
from functions import *
from smart_open import open


class PostgresSQLWriter:

    def createTableSql(self, _schema, table_name, add_not_exist=True):
        schemaSql = ddl_schemaString(_schema, sql_type_mappings, 'TEXT')
        if_not_exists = 'IF NOT EXISTS' if add_not_exist else ''
        # TODO parameters distStyleDef distKeyDef sortKeyDef, if not exists
        sql_create = "CREATE TABLE {} {} ({})".format(if_not_exists, table_name, schemaSql)
        sql_create = re.sub(',\s\)*$', ')', sql_create)  # remove the last ,)
        return sql_create


    def tableExists(self, tablename):
        # TODO there isn't a good way to identify whether a table exists for all. check : another way. maybe catalog
        sql = "SELECT 1 FROM {} LIMIT 1".format(tablename.lower())
        return PostgresSQLConnection.execute_actions(self.conn, sql)


    def write_jdbc(self, _df, db_options, add_not_exist=True):
        maxRecordsPerFile = 100000
        connection = self.conn
        database = db_options['table_name'].split(".")[0]
        postgres_connection = PostgresSQLConnection(connection)
        try:
            if 'pre_action' in db_options:
                if (db_options['pre_action'] != '') & (db_options['pre_action'] != None):
                    postgres_connection.execute_actions( to_fStrings(db_options['pre_action']))

            create_database = "CREATE SCHEMA IF NOT EXISTS {};".format(database)
            #postgres_connection.execute_actions(to_fStrings(create_database))

            sql = self.createTableSql(_df.schema, db_options['table_name'], add_not_exist)
            #postgres_connection.execute_actions(to_fStrings(sql))

            if 'maxRecordsPerFile' in db_options:
                maxRecordsPerFile = maxRecordsPerFile if db_options['maxRecordsPerFile'] == None else db_options['maxRecordsPerFile']


            _df.write \
                .format("jdbc") \
                .mode(db_options['mode']) \
                .option("url", connection['url']) \
                .option("dbtable", db_options['table_name']) \
                .option("user", connection['username']) \
                .option("password", connection['password']) \
                .option("batchsize", maxRecordsPerFile) \
                .save() # pragma: allowlist secret

            # connectionProperties.put("batchsize", "100000")
            # _df.write.jdbc(connection['url'], db_options['table_name'], mode=db_options['mode'],
            # properties={"user": connection['username'], "password": connection['password']}) # pragma: allowlist secret

            if 'post_action' in db_options:
                if (db_options['post_action'] != '') & (db_options['post_action'] != None):
                    postgres_connection.execute_actions(to_fStrings(db_options['post_action']))

        except Exception as e:
            print('Error: {}'.format(e))


    def write_batch(self, _df, db_options, add_not_exist=True):
        audit_process_status = 'success'
        maxRecordsPerFile = 100000
        connection = self.conn
        postgres_connection = PostgresSQLConnection(connection)
        try:
            if 'pre_action' in db_options:
                if (db_options['pre_action'] != '') & (db_options['pre_action'] != None):
                    postgres_connection.execute_actions(to_fStrings(db_options['pre_action']))

            sql = self.createTableSql(_df.schema, db_options['table_name'], add_not_exist)
            postgres_connection.execute_actions(to_fStrings(sql))

            columns_names = _df.columns

            c_conn = postgres_connection.get_connection()
            cursor = c_conn.cursor()

            if 'maxRecordsPerFile' in db_options:
                maxRecordsPerFile = maxRecordsPerFile if db_options['maxRecordsPerFile'] == None else db_options['maxRecordsPerFile']


            path = "/home/hadoop/temp_data/{}.csv".format(db_options['table_name'].replace(".", "_"))

            #_df = _df.coalesce(1)
            _df.write.option("maxRecordsPerFile", maxRecordsPerFile).option("nullValue", None).option("sep", "|").mode(
                "overwrite").csv(path)

            fs = self._spark._jvm.org.apache.hadoop.fs.FileSystem.get(self._spark._jsc.hadoopConfiguration())
            list_status = fs.listStatus(self._spark._jvm.org.apache.hadoop.fs.Path(path))
            result = [file.getPath().getName() for file in list_status]

            for f in result:
                path_file = 'hdfs:/{}/{}'.format(path, f)
                print(f)
                with open(path_file, encoding='utf8') as reader:
                    sql= "COPY {} FROM STDIN WITH DELIMITER AS '|' NULL AS ''".format(db_options['table_name'])
                    cursor.copy_expert(sql,reader )
                    #cursor.copy_from(reader, db_options['table_name'], columns=columns_names, sep='|', null='')

            cursor.close()
            c_conn.commit()
            c_conn.close()

            if 'post_action' in db_options:
                if (db_options['post_action'] != '') & (db_options['post_action'] != None):
                    postgres_connection.execute_actions(to_fStrings(db_options['post_action']))

        except Exception as error:
            audit_process_status = 'error'
            print("Oops! An exception has occured:", error)
            print("Exception TYPE:", type(error))

        return audit_process_status


    def redsfift_copy(self, _df, db_options):
        audit_process_status = 'success'
        maxRecordsPerFile = 100000
        connection = self.conn
        database = db_options['table_name'].split(".")[0]
        postgres_connection = PostgresSQLConnection(connection)
        try:
            if 'pre_action' in db_options:
                if (db_options['pre_action'] != '') & (db_options['pre_action'] != None):
                    postgres_connection.execute_actions(to_fStrings(db_options['pre_action']))
                    print(db_options['pre_action'])

            create_database = "CREATE SCHEMA IF NOT EXISTS {};".format(database)
            #postgres_connection.execute_actions(to_fStrings(create_database))


            sql = self.createTableSql(_df.schema, db_options['table_name'])
            postgres_connection.execute_actions( to_fStrings(sql))
            #print(sql)

            if 'maxRecordsPerFile' in db_options:
                maxRecordsPerFile = maxRecordsPerFile if db_options['maxRecordsPerFile'] == None else db_options[
                    'maxRecordsPerFile']

            path = '{}/temp_data/{}.csv'.format(connection['temp_data'], db_options['table_name'].replace(".", "_"))
            path_out = 's3a://{}'.format(path)

            _df.write.option("maxRecordsPerFile", maxRecordsPerFile).option("nullValue", None).option("sep", "|").mode(
                "overwrite").csv(path_out)

            path_file = 's3://{}'.format(path)  # 'emr://{}/part-*'.format(path)

            copy_command = "COPY {} FROM '{}' iam_role '{}' delimiter '|' NULL AS '@NULL@' ESCAPE EXPLICIT_IDS".format(
                db_options['table_name'], path_file, connection['iam_role'])
            postgres_connection.execute_actions(to_fStrings(copy_command))

            #check select * from stl_load_errors
            errorQuery = 'SELECT * FROM stl_load_errors WHERE query = pg_last_query_id()'
            error = postgres_connection.execute_sql(to_fStrings(errorQuery))

            if len(error) > 0:
                audit_process_status = 'error'
                print("Error-- check stl_load_errors")
            else:
                if 'post_action' in db_options:
                    if (db_options['post_action'] != '') & (db_options['post_action'] != None):
                        postgres_connection.execute_actions(to_fStrings(db_options['post_action']))
                        print(db_options['post_action'])

        except Exception as error:
            audit_process_status = 'error'
            print("Oops! An exception has occured:", error)
            print("Exception TYPE:", type(error))

        return audit_process_status


    def __init__(self, conn, _spark):
        self.conn = conn
        self._spark = _spark
