from connection.athena import AthenaConnection
from functions import *


class HudiWriter:

    def set_df_columns_nullable(self, df, column_list, nullable=False):
        for struct_field in df.schema:
            if struct_field.name in column_list:
                struct_field.nullable = nullable
        _df = self.spark.createDataFrame(df.rdd, df.schema)
        return _df

    def write_table(self, _df, db_options):
        parallelism = 100 # todo check default value Ensure this value is high enough say: 1 partition for 1 GB of input data
        audit_process_status = 'success'
        connection = self.conn
        athena_connection = AthenaConnection(connection, self.athena)
        add = None
        drop = None
        database = db_options['table_name'].split(".")[0]
        tableName = db_options['table_name'].split(".")[1]
        data_bucket_name = "s3://{}/{}".format(connection['data_bucket_name'], tableName)
        location = "{}/{}".format(data_bucket_name, db_options['table_name'])
        if 'parallelism' in db_options:
            parallelism = parallelism if db_options['parallelism'] == None else db_options[
                'parallelism']

        try:
            partition_cols = db_options['partition_key'].split(",")

            if db_options['partition_key'] != 'null':
                PartitionKeysList = db_options['partition_key'].lower().split(",")
                partitionlist = _df.select(*PartitionKeysList).distinct().collect()
                print(partitionlist)
                drop, add = get_actions(connection, partitionlist, db_options['partition_key'], tableName)


             #TODO change   'hoodie.datasource.write.keygenerator.class' according PK

            hudi_options = {
                'hoodie.datasource.write.keygenerator.class': "org.apache.hudi.keygen.ComplexKeyGenerator",
                'hoodie.parquet.compression.codec': 'snappy',
                'hoodie.cleaner.policy': 'KEEP_LATEST_FILE_VERSIONS',
                'hoodie.keep.max.commits': '2',
                'hoodie.keep.min.commits': '1',
                'hoodie.cleaner.commits.retained': '0',
                'hoodie.table.name': tableName,
                'hoodie.datasource.hive_sync.assume_date_partitioning': "false",
                'hoodie.datasource.write.hive_style_partitioning': "true",
                'hoodie.datasource.write.recordkey.field': db_options['primary_key'].lower(),
                'hoodie.datasource.write.partitionpath.field': db_options['partition_key'].lower(),
                'hoodie.datasource.write.table.name': tableName,
                'hoodie.datasource.write.operation': db_options['operation'],
                'hoodie.datasource.write.precombine.field': db_options['partition_key'].lower(),
                'hoodie.datasource.hive_sync.enable': "true",
                'hoodie.datasource.hive_sync.database': database,
                'hoodie.datasource.hive_sync.table': tableName,
                'hoodie.datasource.hive_sync.partition_fields': db_options['partition_key'].lower(),
                'hoodie.datasource.hive_sync.partition_extractor_class': 'org.apache.hudi.hive.MultiPartKeysValueExtractor',
                'hoodie.upsert.shuffle.parallelism': parallelism,
                'hoodie.insert.shuffle.parallelism': parallelism,
                'hoodie.memory.merge.max.size': 2004857600000,
                'hoodie.parquet.max.file.size': 268435456,
                'hoodie.parquet.small.file.limit': 134217728,
                'hoodie.copyonwrite.record.size.estimate': 150
            }

            not_nulls = db_options['primary_key'].lower() + ',' +db_options['partition_key'].lower()
            _df_hudi = self.set_df_columns_nullable(_df, not_nulls.split(","))


            _df_hudi.write.format("hudi"). \
                options(**hudi_options). \
                mode(db_options['mode']). \
                save(data_bucket_name)

            if 'pre_action' in db_options:
                if (db_options['pre_action'] != '') & (db_options['pre_action'] != None):
                    res = athena_connection.execute_actions(to_fStrings(db_options['pre_action']), database)
                    print(db_options['pre_action'])

            #if drop != None:
                #print(drop)
                #res = athena_connection.execute_actions(to_fStrings(drop), database)

            if add != None:
                print(add)
                res = athena_connection.execute_actions(to_fStrings(add), database)
                print('added partitions')
                #queryString = "SHOW PARTITIONS " + tableName
                #res = athena_connection.execute_actions(to_fStrings(queryString), database)

            if 'post_action' in db_options:
                if (db_options['post_action'] != '') & (db_options['post_action'] != None):
                    res = athena_connection.execute_actions(to_fStrings(db_options['post_action']), database)
                    print(db_options['post_action'])

        except Exception as e:
            audit_process_status = 'error'
            print('Error: {}'.format(e))

        return audit_process_status

    def __init__(self, conn, athena, _spark):
        self.conn = conn
        self.athena = athena
        self.spark = _spark